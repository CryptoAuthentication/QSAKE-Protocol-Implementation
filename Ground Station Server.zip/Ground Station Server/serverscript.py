import socket
import threading
import mysql.connector
import oqs
import json
import hashlib
import re
import getpass
import sys
import os
import secrets
import time
from time import process_time
import webbrowser
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import padding
from memory_profiler import memory_usage

Delta_k = 214140748028615609671106732878009013565



mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="qsake"
)
mycursor = mydb.cursor()

def hash_data(data):
    # Compute the SHA-256 hash of the given data
    hash_object = hashlib.sha256(data.encode())
    return hash_object.hexdigest()
	
def load_key():
    # Load GSS_k's private key from the JSON file
    with open("privatekey.json", "r") as priv_file:
        private_key = bytes.fromhex(json.load(priv_file)["private_key"])
    return private_key

def read_json_file():
    #"""Reads the JSON file and returns the data as a dictionary."""
    with open("login_parameters.json", 'r') as file:
        data = json.load(file)
    return data


################################# Start of Keyber-KEM ######################################	
# Load the private key
GSS_k_sk = load_key()
GSS_k_kem = oqs.KeyEncapsulation("Kyber512")
GSS_k_kem.secret_key = GSS_k_sk
################################# End of Keyber-KEM ######################################

#%%%%%%%%%%%%%%%%%% Start of Server Function %%%%%%%%%%%%%%%%%

def open_google_maps(latitude, longitude):
    # Validate the inputs
    if not (-90 <= latitude <= 90) or not (-180 <= longitude <= 180):
        print("Invalid latitude or longitude values")
        return

    # Generate the Google Maps URL with proper format
    google_maps_url = f"https://www.google.com/maps/search/?api=1&query={latitude},{longitude}"

    # Open the URL in the default web browser
    webbrowser.open(google_maps_url)

# Prepare msg_i
def split_msg_i_values(concatenated_data):
    decoded_data = concatenated_data.decode()
    user_id, SID_i, PID_j, n_1 = decoded_data.split(':')  
    return user_id, SID_i, PID_j, n_1 

def extract_records(tidi_value):

    sql_new = "SELECT d_pid, d_enc_records, d_enc_iv, d_enc_tag, id  FROM protocol2 WHERE d_pid = %s AND d_rev_status = 0"	
    mycursor.execute(sql_new, (tidi_value,))
    records_new = mycursor.fetchall()

    extracted_values = None

# Extract and compare the values from the tuples
    for record in records_new:
        if tidi_value == record[0]:
            extracted_values = record[1:]

    return extracted_values

# Function to prepare the AES key from the secret
def prepare_key(secret):
    secret_bytes = secret.to_bytes((secret.bit_length() + 7) // 8, 'big')
    digest = hashes.Hash(hashes.SHA256(), backend=default_backend())
    digest.update(secret_bytes)
    return digest.finalize()[:16]

# Function to decrypt data using AES-GCM
def decrypt_data(key, iv, encrypted_data, tag):
    cipher = Cipher(algorithms.AES(key), modes.GCM(iv, tag), backend=default_backend())
    decryptor = cipher.decryptor()
    return decryptor.update(encrypted_data) + decryptor.finalize()
	
def split_dec_values(data):
    decoded_data = data.decode()
    identity, omega_i_hex = decoded_data.split(':')
    omega_i = bytes.fromhex(omega_i_hex)
    return identity, omega_i
	
# Prepare msg_k     
def concatenate_msg_k_values(n_1, n_2, SID_i):
    return f"{n_1}:{n_2}:{SID_i}".encode()

# Prepare msg_j     
def split_msg_j_values(msg_j_data):
    decoded_msg_j_data = msg_j_data.decode()
    n_3, SID_j, longitude, latitude, timestamp = decoded_msg_j_data.split(':')
    return n_3, SID_j, longitude, latitude, timestamp

# Prepare msg_k_2    
def concatenate_msg_k_2_values(n_3, n_4, SID_j):
    return f"{n_3}:{n_4}:{SID_j}".encode()


#%%%%%%%%%%%%%%%%%% End of Server Function %%%%%%%%%%%%%%%%%

# Calculate memory consumption for each function
memory_consumed_MSG2 = 0
		
# Define variable for CPU time
cpu_time_MSG2 = 0




# Function to handle messages from Remote User
def handle_messages_from_client1(connection, client2_socket):
    try:

# Receive the 4-byte length header
        msg1_length_header = connection.recv(4)
        if not msg1_length_header:
            print("Connection closed by sender.")
            return

# Convert the length header from bytes to an integer
        json_length = int.from_bytes(msg1_length_header, byteorder='big')

# Initialize an empty bytes object for the incoming data
        msg1_json_data = b''

# Receive the JSON data in chunks until the entire length is read
        while len(msg1_json_data) < json_length:
            packet = connection.recv(json_length - len(msg1_json_data))
            if not packet:
                print("Connection closed unexpectedly.")
                break
            msg1_json_data += packet

# Decode and parse the JSON data

            data = json.loads(msg1_json_data.decode('utf-8'))
            print("Received data:", data)
				
   
# Extract the values from json
            retreived_CT_i = data.get("CT_i")
            retreived_Mi_1 = data.get("Mi_1")
            retreived_Mi_2 = data.get("Mi_2")
            print(f"Received Mi_1: {retreived_Mi_1}")
            print(f"Received Mi_2: {retreived_Mi_2}")
            print(f"Received CT_i: {retreived_CT_i}")
	
			
# Converts bytes from hexa
            retreived_CT_i_bytes = bytes.fromhex(retreived_CT_i)
	
# Perform the decryption
            retreived_Chi_i = GSS_k_kem.decap_secret(retreived_CT_i_bytes) 
            print(f"retreived_CT_i: {retreived_Chi_i}")
			
# Converts int from bytes
            Chi_i_int = int.from_bytes(retreived_Chi_i, byteorder='big')
            print(f"Chi_i_int: {Chi_i_int}")

# End of Memory and CPU time for MSG2	
            mem_before_MSG2 = memory_usage()[0]
            start_CPU_time_MSG2 = process_time()  
    
            retreived_msg_i = Chi_i_int ^ int(retreived_Mi_1)
            print(f"retreived_msg_i: {retreived_msg_i}")

            retreived_msg_i_data = retreived_msg_i.to_bytes((retreived_msg_i.bit_length() + 7) // 8, byteorder='big')

            user_id, SID_i, PID_j, n_1  = split_msg_i_values(retreived_msg_i_data)

            print(f"user_id: {user_id}")
            print(f"SID_i: {SID_i}")
            print(f"PID_j: {PID_j}")
            print(f"n_1: {n_1}")

# Computes Eth_i 
            eth_i = hash_data(user_id + str(Delta_k))


# Verifies the equality of Mi_2
            Mi_2_star = hash_data(user_id + SID_i + str(n_1) + eth_i)
            assert Mi_2_star == retreived_Mi_2, f"Verification failed: Mi_2_star != retreived_Mi_2\n{sys.exit(1)}"
            print("User Authentication is Successful")	

# Extracts Drone's data from database against PID_j	
            extracted_values = extract_records(PID_j)
            if extracted_values:
                d_enc_records = extracted_values[0]  #Extracts d_enc_records from queried data
                d_enc_iv = extracted_values[1]  #Extracts d_enc_records from queried data
                d_enc_tag = extracted_values[2]  #Extracts d_enc_records from queried data
                id = extracted_values[3]  #Extracts d_enc_records from queried data
		
################################# Start of AES-GCM ######################################	

# Prepare key
            aes_key = prepare_key(Delta_k)

# Convert hex values back to bytes
            iv_bytes = bytes.fromhex(d_enc_iv)
            encrypted_data_bytes = bytes.fromhex(d_enc_records)
            tag_bytes = bytes.fromhex(d_enc_tag)
            decrypted_data = decrypt_data(aes_key, iv_bytes, encrypted_data_bytes, tag_bytes)
            DID_j, puf_j_output = split_dec_values(decrypted_data)

################################# End of AES-GCM ######################################	
            n_2 = secrets.randbelow(2**128)   
            print(f"n_2: {n_2}")
            eth_j = hash_data(DID_j + str(Delta_k))
    
# Prepare msg_k
            msg_k = concatenate_msg_k_values(n_1, n_2, SID_i)

# Converts msg_i from bytes to integer
            msg_k_int = int.from_bytes(msg_k, byteorder='big')
            print(f"msg_k_int: {msg_k_int}")

# Converts puf_j_output from bytes to integer
            puf_j_output_int = int.from_bytes(puf_j_output,byteorder = 'big')
            print(f"puf_j_output_int: {puf_j_output_int}")

            Mk_1 = msg_k_int ^ puf_j_output_int
            Mk_2 = hash_data(DID_j + eth_j + str(puf_j_output) + str(n_2))

# End of Memory and CPU time for MSG2 		
            mem_after_MSG2 = memory_usage()[0]
            end_CPU_time_MSG2 = process_time()
		
            print(f"Mk_1: {Mk_1}")
            print(f"Mk_2: {Mk_2}")
	
# Prepare Message 2	
            msg2_data2 = {
            "Mk_1": Mk_1,
            "Mk_2": Mk_2}
            json_msg2_data2 = json.dumps(msg2_data2).encode('utf-8')
            	
# Compute Round Trip Time
            RTT_start_time = time.perf_counter()

# Calculate memory consumption for each function
            memory_consumed_MSG2 = mem_after_MSG2 - mem_before_MSG2
		
# Calculate CPU time for each function
            cpu_time_MSG2 = end_CPU_time_MSG2 - start_CPU_time_MSG2 
			
# Send Message to Drone
            client2_socket.sendall(json_msg2_data2)
            print(f"Successfully sent Message 2 {json_msg2_data2.decode()} to Drone:")
            return DID_j, n_2, puf_j_output, Chi_i_int, user_id, eth_i, RTT_start_time
    except Exception as e:
        print(f"Error handling Client1 messages: {e}")

# Function to handle messages from Client2
def handle_messages_from_client2(connection, client1_socket, DID_j, n_2, puf_j_output, Chi_i_int, user_id, eth_i, RTT_start_time):
    try:
        # Receive msg3 from Client2
        msg3 = connection.recv(1024)

# Compute Round Trip Time
        RTT_end_time = time.perf_counter()
		
        if msg3:
            print(f"Received (msg3) from Drone: {msg3.decode()}")


# Receive data from the Drone
            msg3 = msg3.decode('utf-8')

# Convert the received JSON string to a Python dictionary
            data = json.loads(msg3)
    
# Extract the values from json
            retreived_Mj_1 = int(data.get("Mj_1"))
            retreived_Mj_2 = data.get("Mj_2")
            print(f"retreived_Mj_1: {retreived_Mj_1}")
            print(f"retreived_Mj_2: {retreived_Mj_2}")

# End of Memory and CPU time for MSG3	
            mem_before_MSG3 = memory_usage()[0]
            start_CPU_time_MSG3 = process_time()

            retreived_msg_j = int(DID_j, 16) ^ retreived_Mj_1 ^ n_2
            print(f"retreived_msg_j :{retreived_msg_j}")
            retreived_msg_j_data = retreived_msg_j.to_bytes((retreived_msg_j.bit_length() + 7) // 8, byteorder='big')	
            print(f"retreived_msg_j_data :{retreived_msg_j_data}") 
            n_3, SID_j, longitude, latitude, timestamp = split_msg_j_values(retreived_msg_j_data)

#openning GPS coordinates in google map
            open_google_maps(float(latitude), float(longitude))
	
            print(f"n_3: {n_3}")
            print(f"SID_j: {SID_j}")
            print(f"longitude: {longitude}")
            print(f"latitude: {latitude}")
            print(f"timestamp: {timestamp}")
	
            Mj_2_star = hash_data(DID_j + SID_j + str(n_3) + str(puf_j_output))
            assert Mj_2_star == retreived_Mj_2, f"Verification failed: Mj_2_star != retreived_Mj_2\n{sys.exit(1)}"
            print("Drone Authentication is Successful")

# Generates n_4
            n_4 = secrets.randbelow(2**128) 
	
# Prepare msg_k_2

            msg_k_2 = concatenate_msg_k_2_values(n_3, n_4, SID_j)

# Converts msg_i from bytes to integer
            msg_k_2_int = int.from_bytes(msg_k_2, byteorder='big')
            print(f"msg_k_int: {msg_k_2_int}")

            Mk_3 = msg_k_2_int ^ Chi_i_int
            Mk_4 = hash_data(user_id + str(n_4) + eth_i)	

# End of Memory and CPU time for MSG3 		
            mem_after_MSG3 = memory_usage()[0]
            end_CPU_time_MSG3 = process_time()

# Prepare Message 4
            msg4_data4 = {
            "Mk_3": Mk_3,
            "Mk_4": Mk_4}
            json_msg4_data4 = json.dumps(msg4_data4).encode('utf-8')
            	
			
# Send Message to Remote User
            client1_socket.sendall(json_msg4_data4)
            print(f"Successfully sent Message 4 {json_msg4_data4.decode()} to Remote User:")

# Calculate memory consumption for each function
            memory_consumed_MSG3 = mem_after_MSG3 - mem_before_MSG3


#%%%%%%%%%%%%%%%%%%%%%%% Start of Benchmarking %%%%%%%%%%%%%%%#
# Compute total memory consumption
            total_memory_consumed = (memory_consumed_MSG2 + memory_consumed_MSG3)
            print(f"Total memory consumed: {total_memory_consumed:.6f} MB")


# Calculate CPU time for each function
            cpu_time_MSG3 = end_CPU_time_MSG3 - start_CPU_time_MSG3 

# Compute total CPU time
            total_cpu_time = cpu_time_MSG2 + cpu_time_MSG3
            print(f"Total CPU time: {total_cpu_time:.6f} seconds")

# Total Round Trip Time
            total_round_trip_time  = RTT_end_time - RTT_start_time
            print(f"GSS side Round Trip Time: {total_round_trip_time:.4f} seconds")	
#%%%%%%%%%%%%%%%%%%%%%%% End of Benchmarking %%%%%%%%%%%%%%%#	


    except Exception as e:
        print(f"Error handling Client2 messages: {e}")

# Function to manage communication with both clients
def manage_communication(client1_socket, client2_socket):
    # Handle messages from Client1
    DID_j, n_2, puf_j_output, Chi_i_int, user_id, eth_i, RTT_start_time = handle_messages_from_client1(client1_socket, client2_socket)
  
    # Handle messages from Client2
    handle_messages_from_client2(client2_socket, client1_socket, DID_j, n_2, puf_j_output, Chi_i_int, user_id, eth_i, RTT_start_time)

# Main server script
def main():
    host = ''  # Listen on all available interfaces
    port = 11111 

    # Create server socket for listening to clients
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_socket:
        server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server_socket.bind((host, port))
        server_socket.listen(2)
        print(f"Server listening on port {port}...")

        # Accept connections from Client1 and Client2
        client1_socket, client1_addr = server_socket.accept()
        print(f"Connected to Client1: {client1_addr}")

        client2_socket, client2_addr = server_socket.accept()
        print(f"Connected to Client2: {client2_addr}")

        # Start a thread to manage communication between the clients
        communication_thread = threading.Thread(target=manage_communication, args=(client1_socket, client2_socket))
        communication_thread.start()

if __name__ == "__main__":
    main()
