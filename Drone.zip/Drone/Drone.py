import secrets
import hashlib
import json
import os
import base64
import sys
import socket
import cv2
import struct
import socket
import gpsd
import random
import numpy
import serial
import binascii
import bchlib
import numpy as np
from datetime import datetime
import time
from cryptography.fernet import Fernet
from pypuf.simulation import XORArbiterPUF
from pypuf.io import random_inputs
import sys
import numpy
from pymavlink import mavutil
import netifaces
from memory_profiler import memory_usage
from time import process_time
from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
import socket
from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
import cv2
import threading
from queue import Queue


#getting current ip
wifi_interface = 'wlan0'
current_ip = netifaces.ifaddresses(wifi_interface)[netifaces.AF_INET][0]['addr']


def hash_data(data):
    # Compute the SHA-256 hash of the given data
    hash_object = hashlib.sha256(data.encode())
    return hash_object.hexdigest()

def read_login_json_file():
    #"""Reads the JSON file and returns the data as a dictionary."""
    with open("login_parameters.json", 'r') as file:
        data = json.load(file)
    return data

def read_DR_j_Reg_data_file():
    #"""Reads the JSON file and returns the data as a dictionary."""
    with open("DR_j_Rej_data.json", 'r') as file:
        data = json.load(file)
    return data
	
# Prepare msg_k     
def split_msg_k_values(concatenated_data):
    decoded_data = concatenated_data.decode()
    n_1, n_2_star, SID_i = decoded_data.split(':')
    n_2 = int(n_2_star)	
    return n_1, n_2, SID_i 
	
# Prepare msg_j     
def concatenate_msg_j_values(n_3, SID_j, longitude, latitude, timestamp):
    return f"{n_3}:{SID_j}:{longitude}:{latitude}:{timestamp}".encode()		

#Determines PUF output from FPGA
def read_uart(port, baudrate, timeout):
    try:
        ser = serial.Serial(port, baudrate, timeout=timeout)
        
        ser.write(b'\xEB')  
        while True:
            data = ser.readline()
            if data:
                hex_data = ''.join([hex(byte)[2:].zfill(2) for byte in data])
                received_string = len(hex_data)								
                if len(hex_data) == 26:
                    first_18_chars = hex_data[:18]
                    final_64_hex_string = first_18_chars[2:]
                    return final_64_hex_string
                    ser.close()
                    break




    except serial.SerialException as e:
        print("Error:", e)
    finally:
        if ser.is_open:
            ser.close()  # Ensure the serial port is closed


def get_gps_data(master):


    while True:
        # Wait for the GPS_RAW_INT message
        msg = master.recv_match(type='GPS_RAW_INT', blocking=True, timeout=5)
        if msg:
            # Extract GPS information from the message
            latitude = msg.lat / 1e7  # Convert from int32 to float
            longitude = msg.lon / 1e7  # Convert from int32 to float
            timestamp = msg.time_usec  # Microseconds since boot or UNIX epoch

            # Extract other GPS parameters
            fix_type = msg.fix_type
            satellites_visible = msg.satellites_visible
            hdop = msg.eph / 100.0  # Convert from cm to meters

            # Determine GPS fix status
            if fix_type == 0:
                status = "No GPS Fix"
            elif fix_type == 1:
                status = "Low Quality (2D Fix)"
            elif fix_type == 3 and hdop <= 2 and satellites_visible >= 10:
                status = "High Quality (3D Fix)"
            elif fix_type == 3:
                status = "Medium Quality (3D Fix)"
            else:
                status = "Unknown Status"

            print(f"GPS Fix Status: {status}")
            print(f"Latitude: {latitude}, Longitude: {longitude}, Timestamp: {timestamp}")

            # Return GPS data if required, otherwise keep looping
            return longitude, latitude, timestamp
        else:
            print("No GPS data received. Retrying...")
            continue
            
def communicate_with_server():
    host = '192.168.1.58'
    port = 11111

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((host, port))
        print("Connected to Server for relayed communication.")

        # Wait for Message from the GSS
        msg2 = s.recv(1024)
        print(f"Received (msg2) from Server: {msg2.decode()}")
		
# Convert the received JSON string to a Python dictionary
        msg2_data = json.loads(msg2)
    
# Extract the values from storage
        retreived_Mk_1 = msg2_data.get("Mk_1")
        retreived_Mk_2 = msg2_data.get("Mk_2")

# Gets Response Message from PUF
        puf_output = read_uart("/dev/ttyUSB1", 9600, 0.1)
        noisy_puf_output = bytearray(binascii.unhexlify(puf_output))
	
# %%%%%%%%%%%%%%%%%%%%%% Start of Reading registration parameters %%%%%%%%%%%%%%%%%%%%%%%

# Read the JSON file for extracting login parameters
        registration_data = read_DR_j_Reg_data_file()
    
# Extract the values from storage
        stored_ecc = bytearray(binascii.unhexlify(registration_data.get("ecc")))
        stored_key_hash = binascii.unhexlify(registration_data.get("key_hash"))
        stored_sigma_j = registration_data.get("sigma_j")
        stored_tau_j = registration_data.get("tau_j")
        stored_PID_j = registration_data.get("PID_j")

# %%%%%%%%%%%%%%%%%%%%%% End of Reading registration parameters %%%%%%%%%%%%%%%%%%%%%%%  
 
# %%%%%%%%%%%%%%%%%%%%%% Start of Reading login parameters %%%%%%%%%%%%%%%%%%%%%%% 

# BCH parameters
        BCH_T = 6
        BCH_PRIM_POLY = 487

# Initialize BCH encoder/decoder
        bch = bchlib.BCH(BCH_T, prim_poly=BCH_PRIM_POLY)

# Decode the new noisy PUF output with BCH using the stored ECC
        noisy_puf_output_bytearray = bytearray(noisy_puf_output)
        packet = noisy_puf_output_bytearray + stored_ecc
        data, ecc = packet[:-bch.ecc_bytes], packet[-bch.ecc_bytes:]

# Decode
        nerr = bch.decode(data, ecc)

# Correct
        bch.correct(data, ecc)

# Verify the corrected PUF output
        noisy_free_puf_output = bytes(data)  

# End of Memory and CPU time for MSG4		
        mem_before_MSG4 = memory_usage()[0]
        start_CPU_time_MSG4 = process_time() 

# Retreiving DID_j and Eth_i reusing stored parameters
        retreived_DID_j = stored_sigma_j ^ int.from_bytes(noisy_free_puf_output,byteorder = 'big')
        retreived_Eth_j = retreived_DID_j ^ stored_tau_j

        DID_j = hex(retreived_DID_j)[2:] 
        Eth_j = hex(retreived_Eth_j)[2:] 
        print(f"DID_j: {DID_j}")
        print(f"Eth_i: {Eth_j}")
 

# %%%%%%%%%%%%%%%%%%%%%% End of Reading login parameters %%%%%%%%%%%%%%%%%%%%%%%	


        retreived_msg_k = int.from_bytes(noisy_free_puf_output,byteorder = 'big') ^ retreived_Mk_1
        print(f"retreived_msg_k: {retreived_msg_k}")	
	
        retreived_msg_k_data = retreived_msg_k.to_bytes((retreived_msg_k.bit_length() + 7) // 8, byteorder='big')	
        n_1, n_2, SID_i = split_msg_k_values(retreived_msg_k_data)

        print(f"n_1: {n_1}")
        print(f"n_2: {n_2}")
        print(f"SID_i: {SID_i}")

        Mk_2_star = hash_data(DID_j + Eth_j + str(noisy_free_puf_output) + str(n_2))
        assert Mk_2_star == retreived_Mk_2, f"Verification failed: Mk_2_star != retreived_Mk_2\n{sys.exit(1)}"
        print("GSS Authentication is Successful")
	
# Generates n_3	
        n_3 = secrets.randbelow(2**128)
	
# Furnishes location 
        master = mavutil.mavlink_connection('/dev/ttyACM0', baud=9600)    
        master.wait_heartbeat()    
        print("Drone's Heartbeat received:", master.target_system)
        longitude, latitude, timestamp = get_gps_data(master)
        print(f"longitude: {longitude}")
        print(f"latitude: {latitude}")
	
# Get the current IP address
        SID_j = current_ip	
        print(f"SID_j: {SID_j}")
        msg_j = concatenate_msg_j_values(n_3, SID_j, longitude, latitude, timestamp)
        print(f"msg_j : {msg_j}")	

# Converts msg_i from bytes to integer
        msg_j_int = int.from_bytes(msg_j, byteorder='big')
        print(f"msg_j_int: {msg_j_int}")

        Mj_1 = msg_j_int ^ int(DID_j,16) ^ n_2
        Mj_2 = hash_data(DID_j + SID_j + str(n_3) + str(noisy_free_puf_output))

# Establishes Session key 
        SK = hash_data(SID_i + SID_j + stored_PID_j + str(n_1) + str(n_3))
		
# End of Memory and CPU time for MSG4 		
        mem_after_MSG4 = memory_usage()[0]
        end_CPU_time_MSG4 = process_time()		
		
        print(f"Mj_1: {Mj_1}")
        print(f"Mj_2: {Mj_2}")
        print(f"SK: {SK}")
		
# Prepare Message 3	
        msg3_data3 = {
        "Mj_1": Mj_1,
        "Mj_2": Mj_2}
        json_msg3_data3 = json.dumps(msg3_data3).encode('utf-8')

# Compute Round Trip Time
        RTT_start_time = time.perf_counter()
            		
# Send Message to Drone
        s.sendall(json_msg3_data3)
        print(f"Successfully sent Message 3 {json_msg3_data3.decode()} to GSS:")

# Compute total memory consumption
        total_memory_consumed = mem_after_MSG4 - mem_before_MSG4
        print(f"Total memory consumed: {total_memory_consumed:.6f} MB")
		
# Compute total CPU time
        total_cpu_time = end_CPU_time_MSG4 - start_CPU_time_MSG4
        print(f"Total CPU time: {total_cpu_time:.6f} seconds")	
        return SK, SID_i, RTT_start_time 



def capture_frames(cap, frame_queue):
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        frame_queue.put(frame)
       
def handle_direct_communication_with_RM_2(SK, SID_i, RTT_start_time):
    host = "0.0.0.0"  # Server binds to all available network interfaces
    port = 22222  # Port for direct communication
    SHARED_KEY = bytes.fromhex(SK)
    TAG_SIZE = 16  # AES-GCM tag size
    server_address = (host, port)

    # Set up socket to listen for incoming connections
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
        s.bind(server_address)
        print("Server is listening on port", port)

        # Wait for initial request from the client to start the session
        data, client_address = s.recvfrom(1024)  # Receive initial data from the client
        print(f"Received request from {client_address}: {data.decode()}")

# Compute Round Trip Time
        RTT_end_time = time.perf_counter()

# Total Round Trip Time
        total_round_trip_time  = RTT_end_time - RTT_start_time
        print(f"Drone side Round Trip Time: {total_round_trip_time:.4f} seconds")

        # Generate a single nonce for the session
        nonce = get_random_bytes(12)
        
        # Send the session nonce to the client
        s.sendto(nonce, client_address)
        print("Sent session nonce to client, starting video stream")

        # Set up key for encryption
        key = bytes.fromhex(SK) 

        # Capture video from the default camera
        cap = cv2.VideoCapture(0)
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)  
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        cap.set(cv2.CAP_PROP_FPS, 10)

        while True:
            ret, frame = cap.read()
            if not ret:
                break

            # Compress the frame
            encode_param = [int(cv2.IMWRITE_JPEG_QUALITY), 80]  # Adjust quality as needed
            _, frame_bytes = cv2.imencode('.jpg', frame, encode_param)
            frame_data = frame_bytes.tobytes()

            # Create a new cipher object for each encryption using the same nonce
            cipher = AES.new(key, AES.MODE_GCM, nonce=nonce)

            # Encrypt the frame data
            encrypted_frame, tag = cipher.encrypt_and_digest(frame_data)

            # Prepare the packet: frame size (4 bytes) + encrypted frame + tag
            frame_size = len(encrypted_frame) + TAG_SIZE
            frame_size_bytes = frame_size.to_bytes(4, byteorder='big')
            packet = frame_size_bytes + encrypted_frame + tag

            # Send the encrypted frame packet to the client
            s.sendto(packet, client_address)
            print("Sent encrypted video packet to client")

        # Release video capture resources
        cap.release()
        print("Video stream ended")
		

				
if __name__ == "__main__":
    SK, SID_i, RTT_start_time = communicate_with_server()
    print(f"Sk finally established: {SK}")
    print("Direct communnucation with Drone has been started")    
    handle_direct_communication_with_RM_2(SK, SID_i, RTT_start_time)

